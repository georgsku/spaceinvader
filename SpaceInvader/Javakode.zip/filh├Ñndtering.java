package SpaceInvader;

import java.util.ArrayList;

public interface filhåndtering {
	
	ArrayList<String> LeseFraFil();
	void SkrivTilFil(int score);
	
}
